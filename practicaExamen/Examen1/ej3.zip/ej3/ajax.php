<?php
require_once('util.php');

if (isset($_POST['mes'])&&isset($_POST['anyo'])&&$_POST['accion']=='info') {
    $mes = $_POST['mes'];
    $anyo = $_POST['anyo'];
    $numDias = saberDias($mes,$anyo);
    $isBisiesto = saberDias(2,$numDias) == 29;
    $nombreMes = "";
    switch ($mes) {
    case 1: $nombreMes = "Enero";break;
    case 2: $nombreMes = "Febrero";break;
    case 3: $nombreMes = "Marzo";break;
    };
    $mensaje = $isBisiesto ? "El Año es bisiesto" : "El año no es bisiesto";
    return "<label>$nombreMes</label><br>
    <label>$anio</label><br>
    <label>$numDias</label><br>
    <label>$mensaje</label><br>
    ";
}elseif(isset($_POST['mes'])&&isset($_POST['anyo'])&&$_POST['accion']=='select'){
    $mes = $_POST['mes'];
    $anyo = $_POST['anyo'];
    return generarSelectDias($mes,$anyo);
}
else{
    return "No has introducido todos los valores";
}